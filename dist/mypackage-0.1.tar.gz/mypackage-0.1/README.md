# mypackage
xxx

## building this package locally
'python setup.py sdist'

## installing this package from github
sdf

## updating this package from GitHub
ss
